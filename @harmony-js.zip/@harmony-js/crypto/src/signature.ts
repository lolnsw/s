// Copyright (c) 2019 suwei
//
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

/**
 * @packageDocumentation
 * @ignore
 */
